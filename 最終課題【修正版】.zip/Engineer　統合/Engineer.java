import java.util.LinkedHashMap;
import java.io.Serializable;

public class Engineer implements Serializable {
    private static final long serialVersionUID = 1L;
    // ここに中身を書いていくぜ！ 項目名とデータをペアで保管する万能カゴ↓
    // 【解説】項目名（String）とデータ（Object）をペアにして、1つのカゴにまとめて保管する形。Excelの「1行分」のデータを、このdataMapが丸ごと抱え込んでいます。
    private LinkedHashMap<String, Object> dataMap = new LinkedHashMap<>();
    
    // 新しくエンジニアを作ったときに自動で動く初期設定（コンストラクタ）ここにコンストラクタの外枠がガチャンと入るぜ！
    public Engineer() {
        // ここに、最初から必要な項目をカゴに入れる処理を書いていくぜ！
        // カゴに初期項目をセットしていくぜ
        // 【解説】dataMap.put("キー", 初期値) の形。カゴの中に「見出し（キー）」をあらかじめ準備して、中身を空っぽ（または0.0）にしている状態。
        dataMap.put("氏名", "");
        dataMap.put("社員ID", "");
        dataMap.put("生年月日（西暦）", "");
        dataMap.put("入社年月", "");
        dataMap.put("経歴", "");
        dataMap.put("エンジニア歴", "");
        dataMap.put("扱える言語", "");
        dataMap.put("研修の受講歴", "");
        dataMap.put("備考", "");
        dataMap.put("技術力", 0.0);// 小数点を使うため初期値は0.0
        dataMap.put("受講態度", 0.0);
        dataMap.put("コミュニケーション能力", 0.0);
        dataMap.put("リーダーシップ", 0.0);
    }
    //　↓指定された項目のデータを外に教える窓口（ゲッター）
    // 【解説】getValue("項目名") の形。カゴ（dataMap）の中から、指定された項目名のデータを「Object（何でも型）」として外に取り出す窓口。
    public Object getValue(String key) {
        return dataMap.get(key);
    }
    //　↓指定された項目に新しいデータを書き込む窓口（セッター）
    // 【解説】setValue("項目名", 新しいデータ) の形。
    // l指定された項目名のカゴのマス目を、新しいデータで上書き（put）する窓口。
    public void setValue(String key, Object value) {
        dataMap.put(key, value);
    }
}