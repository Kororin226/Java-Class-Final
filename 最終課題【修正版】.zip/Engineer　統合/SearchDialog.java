import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class SearchDialog extends JDialog {

    private EngineerManager manager;
    private MainFrame parentView;

    private JSlider minTechSlider, maxTechSlider;
    private JSlider minAttitudeSlider, maxAttitudeSlider;
    private JSlider minCommSlider, maxCommSlider;
    private JSlider minLeaderSlider, maxLeaderSlider;

    private JCheckBox javaCheck, pythonCheck, cCheck, jsCheck;
    private JComboBox<String> sortCombo;

    public SearchDialog(MainFrame parent, EngineerManager manager) {
        super(parent, true);
        this.manager = manager;
        this.parentView = parent;

        setTitle("検索・並び替え機能");
        setSize(580, 720);
        setLocationRelativeTo(parent);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel idRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        idRow.add(new JLabel("社員ID（部分一致）"));
        JTextField idField = new JTextField(18);
        idRow.add(idField);
        panel.add(idRow);

        JPanel langRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        langRow.add(new JLabel("扱える言語（複数選択可）"));
        javaCheck = new JCheckBox("Java");
        pythonCheck = new JCheckBox("Python");
        cCheck = new JCheckBox("C言語");
        jsCheck = new JCheckBox("JavaScript");
        langRow.add(javaCheck);
        langRow.add(pythonCheck);
        langRow.add(cCheck);
        langRow.add(jsCheck);
        panel.add(langRow);

        panel.add(createSliderPanel("技術力 (0.0～5.0)", 0, 50));
        panel.add(createSliderPanel("受講態度 (0.0～5.0)", 0, 50));
        panel.add(createSliderPanel("コミュニケーション能力 (0.0～5.0)", 0, 50));
        panel.add(createSliderPanel("リーダーシップ (0.0～5.0)", 0, 50));

        JPanel sortRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sortRow.add(new JLabel("並び替え条件"));
        String[] sortOptions = {"指定なし", "社員ID (昇順)", "技術力 (高い順)", "エンジニア歴 (長い順)"};
        sortCombo = new JComboBox<>(sortOptions);
        sortRow.add(sortCombo);
        panel.add(sortRow);

        JButton searchButton = new JButton("検索実行");
        JButton cancelButton = new JButton("キャンセル");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(searchButton);
        buttonPanel.add(cancelButton);

        add(panel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String idKw = idField.getText().trim();

                    List<String> langs = new ArrayList<>();
                    if (javaCheck.isSelected()) langs.add("Java");
                    if (pythonCheck.isSelected()) langs.add("Python");
                    if (cCheck.isSelected()) langs.add("C言語");
                    if (jsCheck.isSelected()) langs.add("JavaScript");

                    double minTech = minTechSlider.getValue() / 10.0;
                    double maxTech = maxTechSlider.getValue() / 10.0;

                    double minAtt = minAttitudeSlider.getValue() / 10.0;
                    double maxAtt = maxAttitudeSlider.getValue() / 10.0;

                    double minComm = minCommSlider.getValue() / 10.0;
                    double maxComm = maxCommSlider.getValue() / 10.0;

                    double minLead = minLeaderSlider.getValue() / 10.0;
                    double maxLead = maxLeaderSlider.getValue() / 10.0;

                    String sortKey = "";
                    boolean isAscending = true;
                    int sortIndex = sortCombo.getSelectedIndex();
                    if (sortIndex == 1) {
                        sortKey = "社員ID";
                        isAscending = true;
                    } else if (sortIndex == 2) {
                        sortKey = "技術力";
                        isAscending = false;
                    } else if (sortIndex == 3) {
                        sortKey = "エンジニア歴";
                        isAscending = false;
                    }

                    ArrayList<Engineer> result = manager.searchEngineers(
                            idKw, langs,
                            minTech, maxTech,
                            minAtt, maxAtt,
                            minComm, maxComm,
                            minLead, maxLead,
                            sortKey, isAscending
                    );

                    parentView.setFilteredEngineers(result);
                    dispose();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(SearchDialog.this,
                            "検索中にエラーが発生しました",
                            "エラー", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener(e -> dispose());
    }

    private JPanel createSliderPanel(String title, int min, int max) {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
        row.add(new JLabel(title));

        JSlider minSlider = new JSlider(min, max, min);
        JSlider maxSlider = new JSlider(min, max, max);

        minSlider.setMajorTickSpacing(max / 5);
        minSlider.setPaintTicks(true);
        maxSlider.setMajorTickSpacing(max / 5);
        maxSlider.setPaintTicks(true);

        JLabel minLabel = new JLabel("0.0");
        JLabel maxLabel = new JLabel("5.0");

        minSlider.addChangeListener(e -> minLabel.setText(String.format("%.1f", minSlider.getValue() / 10.0)));
        maxSlider.addChangeListener(e -> maxLabel.setText(String.format("%.1f", maxSlider.getValue() / 10.0)));

        row.add(minSlider);
        row.add(minLabel);
        row.add(new JLabel(" 〜 "));
        row.add(maxSlider);
        row.add(maxLabel);

        if (title.contains("技術力")) {
            minTechSlider = minSlider;
            maxTechSlider = maxSlider;
        } else if (title.contains("受講態度")) {
            minAttitudeSlider = minSlider;
            maxAttitudeSlider = maxSlider;
        } else if (title.contains("コミュニケーション能力")) {
            minCommSlider = minSlider;
            maxCommSlider = maxSlider;
        } else if (title.contains("リーダーシップ")) {
            minLeaderSlider = minSlider;
            maxLeaderSlider = maxSlider;
        }

        return row;
    }
}