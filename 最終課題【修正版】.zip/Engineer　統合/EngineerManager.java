import java.util.ArrayList;
import java.util.Scanner;
import java.io.*; // ファイル操作のためにこれが必要！

public class EngineerManager {
    // 全員のバインダー（リスト）
    private ArrayList<Engineer> engineerList = new ArrayList<>();
    // 保存するファイル名
    private final String FILE_NAME = "engineers.dat";

    // コンストラクタで起動時に読み込む
    public EngineerManager() {
        load();
    }

    public void addEngineer(Engineer eng) {
        engineerList.add(eng);
        save(); // 追加したら即保存！
    }

    public void removeEngineer(Engineer eng) {
        engineerList.remove(eng);
        save(); // 削除したら即保存！
    }

    public ArrayList<Engineer> getEngineerList() {
        return engineerList;
    }

    // 【追加機能】ファイルからデータを読み込む
    @SuppressWarnings("unchecked")
    private void load() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return; // ファイルがなければ何もしない

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            engineerList = (ArrayList<Engineer>) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 【追加機能】ファイルを保存する
    private void save() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(engineerList);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 📥 【新規追加】CSVファイルから一括で読み込む頭脳（新規・上書き自動判定版！）
    public void importFromCSV(String filename) {
        try (Scanner scanner = new Scanner(new File(filename), "MS932")) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                
                if (data.length >= 8) {
                    String targetID = data[0]; // 取り込んだ行の「社員ID」
                    Engineer existingEngineer = null;
                    
                    // 🧐 すでに同じ社員IDの人が本棚（リスト）にいるか、1人ずつチェックして探す
                    for (Engineer e : engineerList) {
                        if (e.getValue("社員ID") != null && e.getValue("社員ID").equals(targetID)) {
                            existingEngineer = e; // 見つけた！
                            break;
                        }
                    }
                    
                    if (existingEngineer != null) {
                        // 🔄 【上書き更新】すでにある既存データの項目を最新情報で塗り替える！
                        existingEngineer.setValue("氏名", data[1]);
                        existingEngineer.setValue("エンジニア歴", data[2]);
                        existingEngineer.setValue("扱える言語", data[3]);
                        existingEngineer.setValue("技術力", data[4]);
                        existingEngineer.setValue("受講態度", data[5]);
                        existingEngineer.setValue("コミュニケーション能力", data[6]);
                        existingEngineer.setValue("リーダーシップ", data[7]);
                    } else {
                        // 🆕 【新規追加】新しい社員IDだったら、新しい手帳を作って本棚に追加する！
                        Engineer eng = new Engineer();
                        eng.setValue("社員ID", data[0]);
                        eng.setValue("氏名", data[1]);
                        eng.setValue("エンジニア歴", data[2]);
                        eng.setValue("扱える言語", data[3]);
                        eng.setValue("技術力", data[4]);
                        eng.setValue("受講態度", data[5]);
                        eng.setValue("コミュニケーション能力", data[6]);
                        eng.setValue("リーダーシップ", data[7]);
                        
                        engineerList.add(eng);
                    }
                }
            }
            save(); // すべてのインポート・更新が終わったら、自動保存用の.datに即保存！
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    // 📤 【新規追加】現在のすべてのデータをCSVに書き出す頭脳
    public void exportAll(String filename) {
        // 文字化けを防ぐために「MS932」をしっかり指定！
        try (PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(filename), "MS932"))) {
            for (Engineer eng : engineerList) {
                pw.println(
                    eng.getValue("社員ID") + "," +
                    eng.getValue("氏名") + "," +
                    eng.getValue("エンジニア歴") + "," +
                    eng.getValue("扱える言語") + "," +
                    eng.getValue("技術力") + "," +
                    eng.getValue("受講態度") + "," +
                    eng.getValue("コミュニケーション能力") + "," +
                    eng.getValue("リーダーシップ")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public ArrayList<Engineer> searchEngineers(
        String idKeyword,
        java.util.List<String> languages,
        Double minTechSkill, Double maxTechSkill,
        Double minAttitude, Double maxAttitude,
        Double minCommunication, Double maxCommunication,
        Double minLeadership, Double maxLeadership,
        String sortKey, boolean isAscending
) {
    ArrayList<Engineer> result = new ArrayList<>();

    for (Engineer eng : engineerList) {
        boolean match = true;

        // 社員ID（部分一致）
        if (idKeyword != null && !idKeyword.isEmpty()) {
            String id = String.valueOf(eng.getValue("社員ID"));
            if (!id.contains(idKeyword)) {
                match = false;
            }
        }

        // 扱える言語（複数選択対応）
        if (languages != null && !languages.isEmpty()) {
            String lang = String.valueOf(eng.getValue("扱える言語"));
            if (!languages.contains(lang)) {
                match = false;
            }
        }

        // 各種数値項目の範囲チェック
        if (!checkSkillMatch(eng, "技術力", minTechSkill, maxTechSkill)) match = false;
        if (!checkSkillMatch(eng, "受講態度", minAttitude, maxAttitude)) match = false;
        if (!checkSkillMatch(eng, "コミュニケーション能力", minCommunication, maxCommunication)) match = false;
        if (!checkSkillMatch(eng, "リーダーシップ", minLeadership, maxLeadership)) match = false;

        if (match) {
            result.add(eng);
        }
    }

    // ソート処理
    if (sortKey != null && !sortKey.isEmpty()) {
        result.sort((e1, e2) -> {
            String v1 = String.valueOf(e1.getValue(sortKey));
            String v2 = String.valueOf(e2.getValue(sortKey));
            
            if (sortKey.equals("技術力") || sortKey.equals("受講態度") || 
                sortKey.equals("コミュニケーション能力") || sortKey.equals("リーダーシップ") || 
                sortKey.equals("エンジニア歴")) {
                try {
                    double d1 = (v1 == null || v1.isEmpty() || v1.equals("null")) ? 0.0 : Double.parseDouble(v1);
                    double d2 = (v2 == null || v2.isEmpty() || v2.equals("null")) ? 0.0 : Double.parseDouble(v2);
                    return isAscending ? Double.compare(d1, d2) : Double.compare(d2, d1);
                } catch (NumberFormatException e) {
                    // パース失敗時は文字列比較に移行
                }
            }
            return isAscending ? v1.compareTo(v2) : v2.compareTo(v1);
        });
    }

    return result;
}

private boolean checkSkillMatch(Engineer eng, String key, Double min, Double max) {
    try {
        String valStr = String.valueOf(eng.getValue(key));
        if (valStr == null || valStr.isEmpty() || valStr.equals("null")) {
            valStr = "0.0";
        }
        double val = Double.parseDouble(valStr);
        if (min != null && val < min) return false;
        if (max != null && val > max) return false;
    } catch (NumberFormatException e) {
        return false;
    }
    return true;
}
}
