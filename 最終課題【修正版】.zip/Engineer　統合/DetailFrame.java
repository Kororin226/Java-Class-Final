import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class DetailFrame extends JFrame {
    
    private JLabel nameLabel, idLabel, birthLabel, joinLabel, careerLabel, expLabel, langLabel, trainingLabel, remarkLabel;
    private JLabel skillLabel, attitudeLabel, commLabel, leaderLabel;
    
    private JTextField nameField, idField, birthField, joinField, careerField, expField, langField, trainingField, remarkField;
    private JTextField skillField, attitudeField, commField, leaderField;
    
    // 🎛️ 画面に並ぶボタンたち
    private JButton editButton;
    private JButton saveButton;
    private JButton cancelButton; 
    public JButton addButton;         // 新規追加ボタン　publicにすることで一覧画面からでも、新規追加ができるようにしている。
    private Engineer engineer;          // 社員のデータを保持するポケット
    private boolean isNewMode = false;  // 今が「新規追加」か「編集」かを区別するスイッチ

    public DetailFrame(Engineer eng) {
        this.engineer = eng; // 最初に渡された社員データ（佐藤さんなど）をセット
        
        setTitle("社員詳細情報");
        setSize(750, 550); 
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        // --- 🎛️ ボタンたちの配置 ---
        editButton = new JButton("編集");
        editButton.setBounds(620, 20, 80, 30);
        add(editButton);

        saveButton = new JButton("保存");
        saveButton.setBounds(530, 20, 80, 30); 
        add(saveButton);

        cancelButton = new JButton("キャンセル");
        cancelButton.setBounds(620, 20, 95, 30); 
        add(cancelButton);

        addButton = new JButton("新規追加");
        addButton.setBounds(440, 20, 85, 30); 
        add(addButton);

        // 最初は「保存」と「キャンセル」を隠しておく
        saveButton.setVisible(false);
        cancelButton.setVisible(false);

        // --- 左側の配置 ---
        int y = 70; int gap = 45;
        nameLabel = new JLabel("氏名："); nameLabel.setBounds(30, y, 100, 30); add(nameLabel);
        nameField = new JTextField(); nameField.setBounds(150, y, 180, 30); add(nameField);
        
        y += gap;
        idLabel = new JLabel("社員ID："); idLabel.setBounds(30, y, 100, 30); add(idLabel);
        idField = new JTextField(); idField.setBounds(150, y, 180, 30); add(idField);
        
        y += gap;
        birthLabel = new JLabel("生年月日(西暦)："); birthLabel.setBounds(30, y, 110, 30); add(birthLabel);
        birthField = new JTextField(); birthField.setBounds(150, y, 180, 30); add(birthField);
        
        y += gap;
        joinLabel = new JLabel("入社年月："); joinLabel.setBounds(30, y, 100, 30); add(joinLabel);
        joinField = new JTextField(); joinField.setBounds(150, y, 180, 30); add(joinField);
        
        y += gap;
        careerLabel = new JLabel("経歴："); careerLabel.setBounds(30, y, 100, 30); add(careerLabel);
        careerField = new JTextField(); careerField.setBounds(150, y, 180, 30); add(careerField);
        
        y += gap;
        expLabel = new JLabel("エンジニア歴："); expLabel.setBounds(30, y, 100, 30); add(expLabel);
        expField = new JTextField(); expField.setBounds(150, y, 180, 30); add(expField);
        
        y += gap;
        langLabel = new JLabel("扱える言語："); langLabel.setBounds(30, y, 100, 30); add(langLabel);
        langField = new JTextField(); langField.setBounds(150, y, 180, 30); add(langField);
        
        y += gap;
        trainingLabel = new JLabel("研修の受講歴："); trainingLabel.setBounds(30, y, 100, 30); add(trainingLabel);
        trainingField = new JTextField(); trainingField.setBounds(150, y, 180, 30); add(trainingField);

        // --- 右側の配置 ---
        int ry = 70;
        skillLabel = new JLabel("技術力："); skillLabel.setBounds(380, ry, 100, 30); add(skillLabel);
        skillField = new JTextField(); skillField.setBounds(520, ry, 180, 30); add(skillField);
        
        ry += gap;
        attitudeLabel = new JLabel("受講態度："); attitudeLabel.setBounds(380, ry, 100, 30); add(attitudeLabel);
        attitudeField = new JTextField(); attitudeField.setBounds(520, ry, 180, 30); add(attitudeField);
        
        ry += gap;
        commLabel = new JLabel("コミュニケーション："); commLabel.setBounds(380, ry, 130, 30); add(commLabel);
        commField = new JTextField(); commField.setBounds(520, ry, 180, 30); add(commField);
        
        ry += gap;
        leaderLabel = new JLabel("リーダーシップ："); leaderLabel.setBounds(380, ry, 120, 30); add(leaderLabel);
        leaderField = new JTextField(); leaderField.setBounds(520, ry, 180, 30); add(leaderField);

        // --- 下側：備考欄 ---
        y += gap;
        remarkLabel = new JLabel("備考："); remarkLabel.setBounds(30, y, 100, 30); add(remarkLabel);
        remarkField = new JTextField(); remarkField.setBounds(150, y, 550, 30); add(remarkField);

        // 初期データの読み込みと編集ロック
        loadEngineerData(this.engineer);
        setFieldsEditable(false);

        // 🔥 【1】「編集」ボタンが押されたとき
        editButton.addActionListener(e -> {
            isNewMode = false;        // 既存データの編集なので新規モードはOFF
            setFieldsEditable(true);  // 入力可能にする
            nameField.requestFocus();

            // ボタンの表示切り替え
            addButton.setVisible(false);
            editButton.setVisible(false);
            saveButton.setVisible(true);
            cancelButton.setVisible(true);
        });

        // 🔥 【2】「新規追加」ボタンが押されたとき
        addButton.addActionListener(e -> {
            isNewMode = true;         // 新規追加モードをONにする！
            
            // 画面のマス目をすべて空っぽにする
            nameField.setText(""); idField.setText(""); birthField.setText("");
            joinField.setText(""); careerField.setText(""); expField.setText("");
            langField.setText(""); trainingField.setText(""); remarkField.setText("");
            skillField.setText("0.0"); attitudeField.setText("0.0"); commField.setText("0.0"); leaderField.setText("0.0");
            
            setFieldsEditable(true);  // 入力可能にする
            nameField.requestFocus();

            // ボタンの表示切り替え
            addButton.setVisible(false);
            editButton.setVisible(false);
            saveButton.setVisible(true);
            cancelButton.setVisible(true);
        });

        // 🔥 【3】「保存」ボタンが押されたとき
        saveButton.addActionListener(e -> {
            
            // 🛑 社員IDの未記入チェック
            if (idField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "【エラー】\n社員IDを空白のまま保存することはできません。", "入力エラー", JOptionPane.ERROR_MESSAGE);
                return; 
            }
            
            // 🛑 生年月日の8桁超過チェック
            if (birthField.getText().length() > 8) {
                JOptionPane.showMessageDialog(this, "【エラー】\n生年月日は8桁以内で入力してください。（例：19990101）", "入力エラー", JOptionPane.ERROR_MESSAGE);
                return; 
            }

            setFieldsEditable(false); // 閲覧モードに戻す
            
            // 🆕 もし新規追加モードなら、元の佐藤さんとは違う「新しい手帳」を裏で作る！
            if (isNewMode) {
                this.engineer = new Engineer();
            }

            // データを書き込む
            this.engineer.setValue("氏名", nameField.getText());
            this.engineer.setValue("社員ID", idField.getText());
            this.engineer.setValue("生年月日（西暦）", birthField.getText());
            this.engineer.setValue("入社年月", joinField.getText());
            this.engineer.setValue("経歴", careerField.getText());
            this.engineer.setValue("エンジニア歴", expField.getText());
            this.engineer.setValue("扱える言語", langField.getText());
            this.engineer.setValue("研修の受講歴", trainingField.getText());
            this.engineer.setValue("技術力", Double.parseDouble(skillField.getText()));
            this.engineer.setValue("受講態度", Double.parseDouble(attitudeField.getText()));
            this.engineer.setValue("コミュニケーション能力", Double.parseDouble(commField.getText()));
            this.engineer.setValue("リーダーシップ", Double.parseDouble(leaderField.getText()));
            this.engineer.setValue("備考", remarkField.getText());

            JOptionPane.showMessageDialog(this, isNewMode ? "新規社員の登録が完了しました！" : "保存が完了しました！");
            // もし新規追加モードだったら、画面を自動で完全に閉じる
            if (isNewMode) {
            MainFrame.manager.addEngineer(this.engineer); // 👈 これで登録される！
                isNewMode = false;
                dispose();
                return;
            }

            // ボタンとモードを元に戻す
            isNewMode = false;
            addButton.setVisible(true);
            editButton.setVisible(true);
            saveButton.setVisible(false);
            cancelButton.setVisible(false);
        });

        // 🔥 【4】「キャンセル」ボタンが押されたとき
        cancelButton.addActionListener(e -> {
            isNewMode = false; // モードリセット
            
            // 元のデータでリセットする
            loadEngineerData(this.engineer);
            setFieldsEditable(false); 

            // ボタンを元に戻す
            addButton.setVisible(true);
            editButton.setVisible(true);
            saveButton.setVisible(false);
            cancelButton.setVisible(false);
        });
    }

    // 🔒 編集の可否を一括切り替えするメソッド
    private void setFieldsEditable(boolean clickable) {
        nameField.setEditable(clickable); idField.setEditable(clickable); birthField.setEditable(clickable);
        joinField.setEditable(clickable); careerField.setEditable(clickable); expField.setEditable(clickable);
        langField.setEditable(clickable); trainingField.setEditable(clickable); skillField.setEditable(clickable);
        attitudeField.setEditable(clickable); commField.setEditable(clickable); leaderField.setEditable(clickable);
        remarkField.setEditable(clickable);
    }

    // 📥 データを一括で画面にセットするメソッド
    private void loadEngineerData(Engineer eng) {
        if (eng == null) return;
        nameField.setText(String.valueOf(eng.getValue("氏名")));
        idField.setText(String.valueOf(eng.getValue("社員ID")));
        birthField.setText(String.valueOf(eng.getValue("生年月日（西暦）")));
        joinField.setText(String.valueOf(eng.getValue("入社年月")));
        careerField.setText(String.valueOf(eng.getValue("経歴")));
        expField.setText(String.valueOf(eng.getValue("エンジニア歴")));
        langField.setText(String.valueOf(eng.getValue("扱える言語")));
        trainingField.setText(String.valueOf(eng.getValue("研修の受講歴")));
        skillField.setText(String.valueOf(eng.getValue("技術力")));
        attitudeField.setText(String.valueOf(eng.getValue("受講態度")));
        commField.setText(String.valueOf(eng.getValue("コミュニケーション能力")));
        leaderField.setText(String.valueOf(eng.getValue("リーダーシップ")));
        remarkField.setText(String.valueOf(eng.getValue("備考")));
    }
}