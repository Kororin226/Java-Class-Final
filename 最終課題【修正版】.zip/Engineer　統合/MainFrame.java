import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

public class MainFrame extends JFrame {
    public static EngineerManager manager;
    private JTable table;
    private JScrollPane scrollPane;
    private javax.swing.table.DefaultTableModel tableModel;

    // 列の見出しをクラス全体で共有できるように定義
    private final String[] columns = {
        "社員ID","氏名" , "エンジニア歴", "扱える言語", 
        "技術力", "受講態度", "コミュニケーション能力", "リーダーシップ"
    };

    public MainFrame(EngineerManager manager) {
        MainFrame.manager = manager;
        setTitle("社員情報管理アプリ");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // 2. 本棚から全員分のリストを取り出す
        ArrayList<Engineer> list = manager.getEngineerList();
        
        // 3. 表用の二次元配列を用意する
        String[][] data = new String[list.size()][8];
        
        // 4. getValueを使って表のマス目に書き写す
        for (int i = 0; i < list.size(); i++) {
            Engineer eng = list.get(i);
            data[i][0] = String.valueOf(eng.getValue("社員ID"));     
            data[i][1] = String.valueOf(eng.getValue("氏名"));   
            data[i][2] = String.valueOf(eng.getValue("エンジニア歴"));   
            data[i][3] = String.valueOf(eng.getValue("扱える言語"));   
            data[i][4] = String.valueOf(eng.getValue("技術力"));   
            data[i][5] = String.valueOf(eng.getValue("受講態度"));   
            data[i][6] = String.valueOf(eng.getValue("コミュニケーション能力"));   
            data[i][7] = String.valueOf(eng.getValue("リーダーシップ"));  
        }
        
        // 5. 本物の表（JTable）を DefaultTableModel で実体化
        tableModel = new javax.swing.table.DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // すべてのマス目を編集不可にする
            }
        };
        
        table = new JTable(tableModel);
        table.getTableHeader().setResizingAllowed(false); // ユーザーによる列幅の変更を禁止
        table.getTableHeader().setReorderingAllowed(false); // 列のドラッグ移動を禁止する

        scrollPane = new JScrollPane(table);

        // パネルに新規追加ボタンと検索ボタンを乗せて右上に配置する
        JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addButton = new JButton("新規追加");
        JButton searchButton = new JButton("検索");
        
        northPanel.add(addButton);
        northPanel.add(searchButton);
        add(northPanel, BorderLayout.NORTH); // 画面の上にパネルを置く

        // 新規追加ボタンが押されたときの動き
        addButton.addActionListener(e -> {
            // ① 空の手帳を用意する
            Engineer newEngineer = new Engineer();
            
            // ② 詳細画面（DetailFrame）を作る
            DetailFrame detail = new DetailFrame(newEngineer);
            
            // 画面が閉じられた時などに更新するリスナーを登録
            detail.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(java.awt.event.WindowEvent ev) {
                    refreshTable();
                }
                @Override
                public void windowClosing(java.awt.event.WindowEvent ev) {
                    refreshTable();
                }
            });
            
            // 詳細画面の中にある新規追加ボタンを自動でプログラムから押す
            detail.addButton.doClick(); 
            
            // ③ 切り替わった状態で画面を表示する
            detail.setVisible(true);
        });

        // 検索ボタンが押されたときの動き
        searchButton.addActionListener(e -> {
            SearchDialog dialog = new SearchDialog(MainFrame.this, manager);
            dialog.setVisible(true);
        });
        
        // 表（scrollPane）を真ん中いっぱいに広げて配置
        add(scrollPane, BorderLayout.CENTER);

        // 削除ボタン用のパネル
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        // ボタンを新しく作成
        JButton importButton = new JButton("CSVインポート");
        JButton exportButton = new JButton("CSVエクスポート");
        JButton removeButton = new JButton("選択した社員を削除"); 

        // パネルに順番に追加していく
        southPanel.add(importButton);
        southPanel.add(exportButton);
        southPanel.add(removeButton);

        add(southPanel, BorderLayout.SOUTH); // 下に配置

        // CSVインポートボタンを押したときの動き
        importButton.addActionListener(e -> {
            manager.importFromCSV("engineers.csv");
            refreshTable();
            JOptionPane.showMessageDialog(this, "engineers.csv からデータを読み込みました！");
        });

        // CSVエクスポートボタンを押したときの動き
        exportButton.addActionListener(e -> {
            manager.exportAll("engineers.csv");
            JOptionPane.showMessageDialog(this, "engineers.csv へ全データを書き出しました！");
        });
        
        // 削除ボタンの中身
        removeButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            
            if (selectedRow != -1) {
                Engineer engToRemove = manager.getEngineerList().get(selectedRow);
                String msg = "以下の社員を削除しますか？\n" + 
                            "ID: " + engToRemove.getValue("社員ID") + "\n" +
                            "氏名: " + engToRemove.getValue("氏名");

                int result = JOptionPane.showConfirmDialog(this, msg, "削除確認", JOptionPane.YES_NO_OPTION);
                
                if (result == JOptionPane.YES_OPTION) {
                    manager.removeEngineer(engToRemove);
                    
                    javax.swing.table.DefaultTableModel currentModel = (javax.swing.table.DefaultTableModel) table.getModel();
                    currentModel.removeRow(selectedRow);
                    
                    table.revalidate();
                    table.repaint();
                }
            } else {
                JOptionPane.showMessageDialog(this, "削除する社員を選択してください。");
            }
        });

        // ダブルクリックした時だけ詳細画面が開く魔法
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) {
                        // 本棚から該当のエンジニアを引っ張り出す
                        Engineer selectedEngineer = manager.getEngineerList().get(selectedRow);
                        DetailFrame detail = new DetailFrame(selectedEngineer);

                        // 詳細画面の状態変化を検知してテーブルを更新する処理
                        detail.addWindowListener(new java.awt.event.WindowAdapter() {
                            @Override
                            public void windowClosed(java.awt.event.WindowEvent ev) {
                                refreshTable();
                            }
                            @Override
                            public void windowClosing(java.awt.event.WindowEvent ev) {
                                refreshTable();
                            }
                            @Override
                            public void windowDeactivated(java.awt.event.WindowEvent ev) {
                                refreshTable();
                            }
                        });

                        detail.setVisible(true);
                    }
                }
            }
        });
    }

    // テーブルを最新のデータにリフレッシュする共通メソッド
    private void refreshTable() {
        ArrayList<Engineer> latestList = manager.getEngineerList();
        String[][] latestData = new String[latestList.size()][8];
        for (int i = 0; i < latestList.size(); i++) {
            Engineer eng = latestList.get(i);
            latestData[i][0] = String.valueOf(eng.getValue("社員ID"));     
            latestData[i][1] = String.valueOf(eng.getValue("氏名"));   
            latestData[i][2] = String.valueOf(eng.getValue("エンジニア歴"));   
            latestData[i][3] = String.valueOf(eng.getValue("扱える言語"));   
            latestData[i][4] = String.valueOf(eng.getValue("技術力"));   
            latestData[i][5] = String.valueOf(eng.getValue("受講態度"));   
            latestData[i][6] = String.valueOf(eng.getValue("コミュニケーション能力"));   
            latestData[i][7] = String.valueOf(eng.getValue("リーダーシップ"));  
        }
        table.setModel(new javax.swing.table.DefaultTableModel(latestData, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setReorderingAllowed(false);
    }

    // 検索結果を反映するメソッド（コンストラクタの外に配置）
    public void setFilteredEngineers(ArrayList<Engineer> filteredList) {
        String[][] filteredData = new String[filteredList.size()][8];
        for (int i = 0; i < filteredList.size(); i++) {
            Engineer eng = filteredList.get(i);
            filteredData[i][0] = String.valueOf(eng.getValue("社員ID"));     
            filteredData[i][1] = String.valueOf(eng.getValue("氏名"));   
            filteredData[i][2] = String.valueOf(eng.getValue("エンジニア歴"));   
            filteredData[i][3] = String.valueOf(eng.getValue("扱える言語"));   
            filteredData[i][4] = String.valueOf(eng.getValue("技術力"));   
            filteredData[i][5] = String.valueOf(eng.getValue("受講態度"));   
            filteredData[i][6] = String.valueOf(eng.getValue("コミュニケーション能力"));   
            filteredData[i][7] = String.valueOf(eng.getValue("リーダーシップ"));  
        }
        table.setModel(new javax.swing.table.DefaultTableModel(filteredData, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
        table.getTableHeader().setResizingAllowed(false);
        table.getTableHeader().setReorderingAllowed(false);
    }
}