public class AppMain {
    public static void main(String[] args) {
        // 1. 本棚（管理者クラス）を新しく用意する// 【解説】作った手帳（Engineer）を実体化。この時点では中身は初期値（空っぽ）。
        EngineerManager manager = new EngineerManager();
        
        /* 🚨 ここからコメントアウト（起動のたびに追加されるのを防ぐ）
        // 2. お前が作ったルールに合わせて佐藤さんのデータをセット！【解説】setValueの窓口を使って、カゴの特定の場所にデータを「上書き（put）」していく形。
        Engineer sato = new Engineer();
        sato.setValue("氏名", "佐藤");// "氏名"のペアを"佐藤"に上書き
        sato.setValue("社員ID", "S001");// "社員ID"のペアを"S001"に上書き
        sato.setValue("技術力", 3.5); // 小数点だから3.5とかにしてみたぜ！// "技術力"のペアを3.5に上書き
        
        // 本棚に住まわせる
        manager.addEngineer(sato);
        */ //🚨 ここまでコメントアウト。初期設定だからあとで使うかもしれない？かな・・・
        
        // 3. 一覧画面（MainFrame）に本棚を手渡して実体化！
        MainFrame frame = new MainFrame(manager);
        frame.setVisible(true);
    }
}